 
<html lang =en>
    <div class="footer" style= "text-align: center;position:absolute;margin-left:-50px;left:50%;width:50px;bottom:20px;" > 
        <form action="activity_update.php" style= "text-align: center;">
            <input type="submit" value="UPDATE Existing RECORD"><br/> <br/> 
        </form>
        <form action="activity_delete.php" style= "text-align: center;">
            <input type="submit" value="DELETE Existing RECORD"><br/> <br/> 
        </form>
        <form action="activity_insert.php" style= "text-align: center;"> 
            <input type="submit" value="LOG NEW Activity"><br/> <br/>  
        </form>
        <form action="visualize_menu.php" style= "text-align: center;">
            <input type="submit" value="VISUALIZE MY ACTIVITY"><br/> <br/> 
        </form>
        <form action="home.php" style= "text-align: center;">
            <input type="submit" value="RETURN TO HOME">   
        </form>

    </div>    

</html>