<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
</head>
<body>
    <form class="" action="" method="post" autocomplete="off">
    <h1 style="text-align: center;">Update Record</h1>
        <center><label for="">Activity Record id</label></center>
        <center><input type="number" name="Activity_Record_id" required value=""><br></center>
        <br>
        <center><label for=""> Update Date of Record</label></center>
        <center><input type="date" name="dateOfRecord" required value=""><br></center>
        <br>
        <center><label for="">Update Activity type</label></center>
        <center><input type="text" name="activeRecord" required value=""><br></center>
        <br>
        <center><label for="">Update Active Minutes</label></center>
        <center><input type="number" name="Update_Active_Minutes" required value=""><br></center>
        <br>
        <center><label for="">Update Calorie Burned</label></center>
        <center><input type="number" name="calorieBurned" required value=""><br></center>
        <br>
        <center><label for="">Update Duration</label></center>
        <center><input type="number" name="duration" required value=""><br></center>
        <br>
        <center><label for="">Update Steps Taken</label></center>
        <center><input type="number" name="stepsTaken" required value=""><br></center>
        <br>
        <center><button type="submit" name="submit">update</button>
    </form>
</body>
</html>