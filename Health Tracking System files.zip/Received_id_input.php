<html lang = 'en'>
    <form action="view_specific_messages.php" style="margin-left: 35px; text-align: center;" method="POST">
        <p> INPUT ID OF USER YOU WANT TO CONNECT WITH </p>
        ID: <input type="number" name="sid"> <br/>
        <input type="submit" value="Check last message sent to me">
    </form>
</html>    