<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Id</title>
</head>
<body>
    <form class="" action="" method="post" autocomplete="off">
    <h1 style="text-align: center;">Delete Activity Record</h1>
    <center><label for="">Activity record id</label></center>
    <center><input type="number" name="activityrecordid" required value=""><br></center>

    <br>
    <center><button type="submit" name="submit">Delete button</button></button></center>
    </form>
</body>
</html>