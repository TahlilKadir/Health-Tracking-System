<html lang =en>
    <div class="footer" style= "text-align: center; " > 
        <h> CHOOSE THE RECORD YOU WANT TO VISULIZE</h><br/><br/>
        <form action="visualize_steps.php" style= "text-align: center;">
            <input type="submit" value="STEPS TAKEN"><br/><br/>
        </form>
        <form action="visualize_calorie.php" style= "text-align: center;">
            <input type="submit" value="CALORIES BURNT"><br/><br/>
        </form>
        <form action="visualize_minutes.php" style= "text-align: center;"> 
            <input type="submit" value="ACTIVE MINUTES"><br/> <br/>
        </form>
        </form>
        <form action="activity_view.php" style= "text-align: center;">
            <input type="submit" value="RETURN TO RECORD VIEW"><br/> 
        </form>
    </div>    

</html>