<html lang ="en">
    <body>
        <section id="info_inp">
            <form action="create_account.php" class= "field_input" method="Post" style= "text-align: center">
            <p style="font-size: 22px"> Fill up form to Register</p><br/><br/><br/>
             Username: <input type="text" name="uname"> <br/><br/>
			 Name: <input type="text" name="jname"> <br/> <br/>
             Email: <input type="text" name="mail"> <br/> <br/>
			 Password: <input type="password" name="pass"> <br/> <br/>
             Gender: <input type="text" name="sex"> <br/> <br/>
			 Date of birth: <input type="date" name="dob"> <br/> <br/>
             <input type = "submit" value="Register">
            </form>
        </section>
    </body>
</html>