<html lang="en">
  	<body> 
		<section id="header">
			<div class="title" style= "background-color:#191970;" >
				<br/>  
				<div class="col-md-10" style="font-size: 40px;color:#F2674A; text-align: center; background-color:#191970 "> B-Healthy </div>
				<br/> 
			</div>
		</section>
		
		<section id = "section1">
			<br/> <br/><br/><br/> <br/>
			<div class="title" style= "color:#Bg5343; text-align: center; font-size: 20px"> LOG IN <br/> <br/> </div>
			
			<form action="login.php" class="form_design" method="post" style= "text-align: center">
				Username: <input type="text" name="hname"> <br/>
				Password: <input type="password" name="pas"> <br/> <br/>
				<input type="submit" value="Sign In">
			</form>
			<div class = "links" style= "text-align: center">
				Don't have an account? <a href = "register.php"> Sign-up </a>
			</div>  
		</section>
	</body>	
</html>

