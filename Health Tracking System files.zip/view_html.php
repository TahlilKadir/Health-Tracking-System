<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viewing All Activity Record Data</title>
</head>
<body>
    <form class="" action="" method="post" autocomplete="off">
        <h1 style="text-align: center;">Viewing Activity Record Data</h1>
    </form>
    
</body>
</html>